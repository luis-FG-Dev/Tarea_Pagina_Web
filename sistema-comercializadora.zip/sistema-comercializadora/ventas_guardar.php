<?php
require 'config.php';
require 'includes/auth.php';
requerir_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ventas.php');
    exit;
}

$cliente_id  = (int) $_POST['cliente_id'];
$productosId = $_POST['producto_id'] ?? [];
$cantidades  = $_POST['cantidad'] ?? [];
$usuario     = usuario_actual();

if (empty($productosId)) {
    die('La venta debe tener al menos un producto.');
}

// Una transacción asegura que TODO se guarde (venta + detalle + stock)
// o NADA se guarde si algo falla a mitad de camino.
$pdo->beginTransaction();

try {
    $total = 0;

    // Primero se valida que haya stock suficiente y se calcula el total,
    // antes de escribir nada en la base de datos.
    $lineas = [];
    foreach ($productosId as $i => $productoId) {
        $productoId = (int) $productoId;
        $cantidad   = (int) $cantidades[$i];

        $stmt = $pdo->prepare('SELECT * FROM producto WHERE id = ? FOR UPDATE');
        $stmt->execute([$productoId]);
        $producto = $stmt->fetch();

        if (!$producto) {
            throw new Exception("Producto no encontrado (id $productoId).");
        }
        if ($cantidad <= 0) {
            throw new Exception("Cantidad inválida para {$producto['nombre']}.");
        }
        if ($producto['stock'] < $cantidad) {
            throw new Exception("Stock insuficiente para {$producto['nombre']} (disponible: {$producto['stock']}).");
        }

        $subtotal = $producto['precio'] * $cantidad;
        $total += $subtotal;

        $lineas[] = [
            'producto_id' => $productoId,
            'cantidad'    => $cantidad,
            'precio'      => $producto['precio'],
            'subtotal'    => $subtotal,
        ];
    }

    // 1. Cabecera de la venta
    $stmt = $pdo->prepare('INSERT INTO venta (cliente_id, usuario_id, total) VALUES (?,?,?)');
    $stmt->execute([$cliente_id, $usuario['id'], $total]);
    $ventaId = $pdo->lastInsertId();

    // 2. Detalle de la venta + descuento de stock + movimiento de inventario
    $insertDetalle    = $pdo->prepare('INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (?,?,?,?,?)');
    $actualizarStock  = $pdo->prepare('UPDATE producto SET stock = stock - ? WHERE id = ?');
    $insertMovimiento = $pdo->prepare("INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, motivo) VALUES (?, 'salida', ?, ?)");

    foreach ($lineas as $linea) {
        $insertDetalle->execute([$ventaId, $linea['producto_id'], $linea['cantidad'], $linea['precio'], $linea['subtotal']]);
        $actualizarStock->execute([$linea['cantidad'], $linea['producto_id']]);
        $insertMovimiento->execute([$linea['producto_id'], $linea['cantidad'], "Venta #$ventaId"]);
    }

    $pdo->commit();
    header("Location: ventas_detalle.php?id=$ventaId");
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    die('No se pudo registrar la venta: ' . $e->getMessage());
}
