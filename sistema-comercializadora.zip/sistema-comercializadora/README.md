# Sistema de ventas e inventario — Comercializadora

Aplicación web sencilla en PHP + MySQL para reemplazar la gestión manual
de ventas, inventario y clientes de una comercializadora de ropa,
alimentos y artículos para el hogar.

## Requisitos
- XAMPP, WAMP, Laragon o cualquier servidor con PHP 8+ y MySQL/MariaDB.

## Instalación
1. Copia la carpeta `sistema-comercializadora` dentro de `htdocs`
   (o la carpeta pública de tu servidor).
2. Abre phpMyAdmin (o la consola de MySQL) y ejecuta el archivo `schema.sql`.
   Esto crea la base de datos `comercializadora`, sus 7 tablas y datos de ejemplo.
3. Abre `config.php` y ajusta `$DB_USER` / `$DB_PASS` según tu instalación
   (por defecto XAMPP usa usuario `root` y contraseña vacía).
4. Entra en el navegador a `http://localhost/sistema-comercializadora/`.
5. Inicia sesión con el usuario de prueba:
   - Correo: `admin@tienda.com`
   - Contraseña: `admin123`

## Estructura del proyecto
```
config.php              conexión a la base de datos (PDO)
schema.sql               script SQL: tablas + datos de ejemplo
index.php                 login
logout.php                 cierra sesión
dashboard.php               panel con indicadores (ventas del día, stock bajo)
productos.php                 CRUD de productos
clientes.php                   CRUD de clientes
ventas.php                      formulario para registrar una venta
ventas_guardar.php                procesa la venta (transacción + descuenta stock)
ventas_historial.php               listado de ventas
ventas_detalle.php                  detalle de una venta puntual
includes/auth.php                    controla la sesión (exige login)
includes/header.php                   menú de navegación
includes/footer.php                    cierre del HTML
css/style.css                          estilos propios sobre Bootstrap
```

## Cómo se mueve el inventario
Cada vez que se registra una venta (`ventas_guardar.php`):
1. Se valida que haya stock suficiente de cada producto.
2. Se crea la cabecera en `venta` y una fila por producto en `detalle_venta`.
3. Se descuenta la cantidad vendida del `stock` en `producto`.
4. Se guarda un registro de salida en `movimiento_inventario`, para
   tener trazabilidad de por qué bajó el stock.

Todo el proceso ocurre dentro de una transacción (`beginTransaction` /
`commit` / `rollBack`): si algo falla a mitad de camino (por ejemplo,
stock insuficiente en el segundo producto), no se guarda nada, evitando
que quede una venta "a medias".
