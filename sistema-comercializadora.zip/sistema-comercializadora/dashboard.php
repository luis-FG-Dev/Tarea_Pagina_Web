<?php
require 'config.php';
require 'includes/auth.php';
requerir_login();

$titulo = 'Panel';

// Indicadores rápidos para la pantalla principal
$totalProductos = $pdo->query('SELECT COUNT(*) FROM producto')->fetchColumn();
$totalClientes  = $pdo->query('SELECT COUNT(*) FROM cliente')->fetchColumn();

$ventasHoy = $pdo->query(
    "SELECT COUNT(*) AS cantidad, COALESCE(SUM(total), 0) AS total
     FROM venta WHERE DATE(fecha) = CURDATE()"
)->fetch();

$stockBajo = $pdo->query(
    'SELECT nombre, stock, stock_minimo FROM producto
     WHERE stock <= stock_minimo ORDER BY stock ASC'
)->fetchAll();

require 'includes/header.php';
?>

<h3 class="mb-4">Panel</h3>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="card p-3">
      <div class="text-muted small">Productos</div>
      <div class="fs-3"><?= $totalProductos ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card p-3">
      <div class="text-muted small">Clientes</div>
      <div class="fs-3"><?= $totalClientes ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card p-3">
      <div class="text-muted small">Ventas de hoy</div>
      <div class="fs-3"><?= $ventasHoy['cantidad'] ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card p-3">
      <div class="text-muted small">Total vendido hoy</div>
      <div class="fs-3">$<?= number_format($ventasHoy['total'], 0, ',', '.') ?></div>
    </div>
  </div>
</div>

<div class="card p-3">
  <h5>Productos con stock bajo</h5>
  <?php if (empty($stockBajo)): ?>
    <p class="text-muted mb-0">No hay productos por debajo de su stock mínimo.</p>
  <?php else: ?>
    <table class="table table-sm mb-0">
      <thead><tr><th>Producto</th><th>Stock actual</th><th>Stock mínimo</th></tr></thead>
      <tbody>
      <?php foreach ($stockBajo as $p): ?>
        <tr>
          <td><?= htmlspecialchars($p['nombre']) ?></td>
          <td class="stock-bajo"><?= $p['stock'] ?></td>
          <td><?= $p['stock_minimo'] ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require 'includes/footer.php'; ?>
