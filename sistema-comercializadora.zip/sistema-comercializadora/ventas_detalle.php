<?php
require 'config.php';
require 'includes/auth.php';
requerir_login();

$titulo = 'Detalle de venta';
$ventaId = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT v.*, c.nombre AS cliente_nombre, u.nombre AS usuario_nombre
     FROM venta v
     JOIN cliente c ON c.id = v.cliente_id
     JOIN usuario u ON u.id = v.usuario_id
     WHERE v.id = ?'
);
$stmt->execute([$ventaId]);
$venta = $stmt->fetch();

if (!$venta) {
    die('Venta no encontrada.');
}

$stmt = $pdo->prepare(
    'SELECT d.*, p.nombre AS producto_nombre
     FROM detalle_venta d JOIN producto p ON p.id = d.producto_id
     WHERE d.venta_id = ?'
);
$stmt->execute([$ventaId]);
$items = $stmt->fetchAll();

require 'includes/header.php';
?>

<h3 class="mb-4">Venta #<?= $venta['id'] ?></h3>

<div class="card p-3 mb-3">
  <p class="mb-1"><strong>Cliente:</strong> <?= htmlspecialchars($venta['cliente_nombre']) ?></p>
  <p class="mb-1"><strong>Vendedor:</strong> <?= htmlspecialchars($venta['usuario_nombre']) ?></p>
  <p class="mb-0"><strong>Fecha:</strong> <?= htmlspecialchars($venta['fecha']) ?></p>
</div>

<div class="card p-3">
  <table class="table">
    <thead><tr><th>Producto</th><th>Cantidad</th><th>Precio unitario</th><th>Subtotal</th></tr></thead>
    <tbody>
    <?php foreach ($items as $i): ?>
      <tr>
        <td><?= htmlspecialchars($i['producto_nombre']) ?></td>
        <td><?= $i['cantidad'] ?></td>
        <td>$<?= number_format($i['precio_unitario'], 0, ',', '.') ?></td>
        <td>$<?= number_format($i['subtotal'], 0, ',', '.') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr><th colspan="3" class="text-end">Total</th><th>$<?= number_format($venta['total'], 0, ',', '.') ?></th></tr>
    </tfoot>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
