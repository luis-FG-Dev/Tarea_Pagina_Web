<?php
require 'config.php';
require 'includes/auth.php';
requerir_login();

$titulo = 'Productos';
$mensaje = '';

// ------------------------------------------------------------
// Procesar el formulario (crear o editar) cuando llega por POST
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar') {
    $id           = $_POST['id'] ?: null;
    $nombre       = trim($_POST['nombre']);
    $categoria_id = (int) $_POST['categoria_id'];
    $descripcion  = trim($_POST['descripcion']);
    $precio       = (float) $_POST['precio'];
    $stock        = (int) $_POST['stock'];
    $stock_minimo = (int) $_POST['stock_minimo'];

    if ($id) {
        // UPDATE: edita un producto existente
        $stmt = $pdo->prepare(
            'UPDATE producto SET categoria_id=?, nombre=?, descripcion=?, precio=?, stock=?, stock_minimo=? WHERE id=?'
        );
        $stmt->execute([$categoria_id, $nombre, $descripcion, $precio, $stock, $stock_minimo, $id]);
        $mensaje = 'Producto actualizado.';
    } else {
        // INSERT: crea un producto nuevo
        $stmt = $pdo->prepare(
            'INSERT INTO producto (categoria_id, nombre, descripcion, precio, stock, stock_minimo) VALUES (?,?,?,?,?,?)'
        );
        $stmt->execute([$categoria_id, $nombre, $descripcion, $precio, $stock, $stock_minimo]);
        $mensaje = 'Producto creado.';
    }
}

// ------------------------------------------------------------
// Eliminar (llega como ?eliminar=ID)
// ------------------------------------------------------------
if (isset($_GET['eliminar'])) {
    $stmt = $pdo->prepare('DELETE FROM producto WHERE id = ?');
    $stmt->execute([(int) $_GET['eliminar']]);
    $mensaje = 'Producto eliminado.';
}

// Si viene ?editar=ID, cargamos ese producto para precargar el formulario
$productoEditar = null;
if (isset($_GET['editar'])) {
    $stmt = $pdo->prepare('SELECT * FROM producto WHERE id = ?');
    $stmt->execute([(int) $_GET['editar']]);
    $productoEditar = $stmt->fetch();
}

$categorias = $pdo->query('SELECT * FROM categoria ORDER BY nombre')->fetchAll();

$productos = $pdo->query(
    'SELECT p.*, c.nombre AS categoria_nombre
     FROM producto p JOIN categoria c ON c.id = p.categoria_id
     ORDER BY p.nombre'
)->fetchAll();

require 'includes/header.php';
?>

<h3 class="mb-4">Productos</h3>

<?php if ($mensaje): ?>
  <div class="alert alert-success"><?= htmlspecialchars($mensaje) ?></div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="card p-3">
      <h5><?= $productoEditar ? 'Editar producto' : 'Nuevo producto' ?></h5>
      <form method="post">
        <input type="hidden" name="accion" value="guardar">
        <input type="hidden" name="id" value="<?= htmlspecialchars($productoEditar['id'] ?? '') ?>">

        <div class="mb-2">
          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" class="form-control" required
                 value="<?= htmlspecialchars($productoEditar['nombre'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label">Categoría</label>
          <select name="categoria_id" class="form-select" required>
            <?php foreach ($categorias as $c): ?>
              <option value="<?= $c['id'] ?>"
                <?= (($productoEditar['categoria_id'] ?? null) == $c['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['nombre']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label">Descripción</label>
          <input type="text" name="descripcion" class="form-control"
                 value="<?= htmlspecialchars($productoEditar['descripcion'] ?? '') ?>">
        </div>
        <div class="row">
          <div class="col-6 mb-2">
            <label class="form-label">Precio</label>
            <input type="number" step="0.01" name="precio" class="form-control" required
                   value="<?= htmlspecialchars($productoEditar['precio'] ?? '0') ?>">
          </div>
          <div class="col-6 mb-2">
            <label class="form-label">Stock</label>
            <input type="number" name="stock" class="form-control" required
                   value="<?= htmlspecialchars($productoEditar['stock'] ?? '0') ?>">
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Stock mínimo</label>
          <input type="number" name="stock_minimo" class="form-control" required
                 value="<?= htmlspecialchars($productoEditar['stock_minimo'] ?? '5') ?>">
        </div>
        <button class="btn btn-primary w-100" type="submit">Guardar</button>
        <?php if ($productoEditar): ?>
          <a href="productos.php" class="btn btn-link w-100">Cancelar edición</a>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card p-3">
      <table class="table align-middle">
        <thead>
          <tr><th>Nombre</th><th>Categoría</th><th>Precio</th><th>Stock</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($productos as $p): ?>
          <tr>
            <td><?= htmlspecialchars($p['nombre']) ?></td>
            <td><?= htmlspecialchars($p['categoria_nombre']) ?></td>
            <td>$<?= number_format($p['precio'], 0, ',', '.') ?></td>
            <td class="<?= $p['stock'] <= $p['stock_minimo'] ? 'stock-bajo' : '' ?>"><?= $p['stock'] ?></td>
            <td class="text-end">
              <a href="productos.php?editar=<?= $p['id'] ?>" class="btn btn-sm btn-outline-secondary">Editar</a>
              <a href="productos.php?eliminar=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger"
                 onclick="return confirm('¿Eliminar este producto?')">Eliminar</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
