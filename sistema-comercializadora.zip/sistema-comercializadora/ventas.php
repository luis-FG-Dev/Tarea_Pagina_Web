<?php
require 'config.php';
require 'includes/auth.php';
requerir_login();

$titulo = 'Nueva venta';

$clientes  = $pdo->query('SELECT * FROM cliente ORDER BY nombre')->fetchAll();
$productos = $pdo->query('SELECT * FROM producto ORDER BY nombre')->fetchAll();

require 'includes/header.php';
?>

<h3 class="mb-4">Registrar venta</h3>

<form method="post" action="ventas_guardar.php" class="card p-3" id="form-venta">
  <div class="mb-3 col-md-5">
    <label class="form-label">Cliente</label>
    <select name="cliente_id" class="form-select" required>
      <?php foreach ($clientes as $c): ?>
        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <table class="table" id="tabla-items">
    <thead><tr><th>Producto</th><th style="width:120px">Cantidad</th><th style="width:120px">Precio</th><th></th></tr></thead>
    <tbody></tbody>
  </table>

  <button type="button" class="btn btn-outline-secondary btn-sm mb-3" id="btn-agregar" style="width:fit-content">
    + Agregar producto
  </button>

  <div class="text-end fs-5 mb-3">Total: $<span id="total-venta">0</span></div>

  <button class="btn btn-primary" type="submit">Registrar venta</button>
</form>

<!-- Los productos y precios se guardan en JSON para que el JavaScript
     arme las filas sin volver a consultar la base de datos -->
<script>
const productos = <?= json_encode($productos, JSON_UNESCAPED_UNICODE) ?>;

const tbody = document.querySelector('#tabla-items tbody');

function opcionesProductos(seleccionado) {
  return productos.map(p =>
    `<option value="${p.id}" data-precio="${p.precio}" data-stock="${p.stock}"
       ${p.id == seleccionado ? 'selected' : ''}>${p.nombre} (stock: ${p.stock})</option>`
  ).join('');
}

function agregarFila() {
  const fila = document.createElement('tr');
  fila.innerHTML = `
    <td>
      <select name="producto_id[]" class="form-select producto-select" required>
        ${opcionesProductos(null)}
      </select>
    </td>
    <td><input type="number" name="cantidad[]" class="form-control cantidad-input" value="1" min="1" required></td>
    <td class="precio-celda">0</td>
    <td><button type="button" class="btn btn-sm btn-outline-danger btn-quitar">x</button></td>
  `;
  tbody.appendChild(fila);
  actualizarFila(fila);
}

function actualizarFila(fila) {
  const select = fila.querySelector('.producto-select');
  const opcion = select.options[select.selectedIndex];
  const precio = opcion ? parseFloat(opcion.dataset.precio) : 0;
  fila.querySelector('.precio-celda').textContent = precio.toLocaleString('es-CO');
  calcularTotal();
}

function calcularTotal() {
  let total = 0;
  tbody.querySelectorAll('tr').forEach(fila => {
    const select = fila.querySelector('.producto-select');
    const opcion = select.options[select.selectedIndex];
    const precio = opcion ? parseFloat(opcion.dataset.precio) : 0;
    const cantidad = parseFloat(fila.querySelector('.cantidad-input').value) || 0;
    total += precio * cantidad;
  });
  document.getElementById('total-venta').textContent = total.toLocaleString('es-CO');
}

document.getElementById('btn-agregar').addEventListener('click', agregarFila);

tbody.addEventListener('change', e => {
  if (e.target.classList.contains('producto-select')) actualizarFila(e.target.closest('tr'));
  if (e.target.classList.contains('cantidad-input')) calcularTotal();
});
tbody.addEventListener('input', e => {
  if (e.target.classList.contains('cantidad-input')) calcularTotal();
});
tbody.addEventListener('click', e => {
  if (e.target.classList.contains('btn-quitar')) {
    e.target.closest('tr').remove();
    calcularTotal();
  }
});

// Arranca con una fila lista para usar
agregarFila();
</script>

<?php require 'includes/footer.php'; ?>
