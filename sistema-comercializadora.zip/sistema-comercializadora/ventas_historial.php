<?php
require 'config.php';
require 'includes/auth.php';
requerir_login();

$titulo = 'Historial de ventas';

$ventas = $pdo->query(
    'SELECT v.*, c.nombre AS cliente_nombre, u.nombre AS usuario_nombre
     FROM venta v
     JOIN cliente c ON c.id = v.cliente_id
     JOIN usuario u ON u.id = v.usuario_id
     ORDER BY v.fecha DESC'
)->fetchAll();

require 'includes/header.php';
?>

<h3 class="mb-4">Historial de ventas</h3>

<div class="card p-3">
  <table class="table align-middle">
    <thead><tr><th>#</th><th>Fecha</th><th>Cliente</th><th>Vendedor</th><th>Total</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($ventas as $v): ?>
      <tr>
        <td>#<?= $v['id'] ?></td>
        <td><?= htmlspecialchars($v['fecha']) ?></td>
        <td><?= htmlspecialchars($v['cliente_nombre']) ?></td>
        <td><?= htmlspecialchars($v['usuario_nombre']) ?></td>
        <td>$<?= number_format($v['total'], 0, ',', '.') ?></td>
        <td class="text-end"><a href="ventas_detalle.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-secondary">Ver detalle</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
