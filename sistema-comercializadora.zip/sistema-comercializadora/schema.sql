-- ============================================================
-- schema.sql
-- Base de datos para el sistema de ventas e inventario
-- de la comercializadora (ropa, alimentos, hogar)
-- ============================================================

CREATE DATABASE IF NOT EXISTS comercializadora
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE comercializadora;

-- ------------------------------------------------------------
-- CATEGORIA: agrupa los productos (ropa, alimentos, hogar...)
-- ------------------------------------------------------------
CREATE TABLE categoria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL
);

-- ------------------------------------------------------------
-- USUARIO: empleados que ingresan al sistema (login)
-- ------------------------------------------------------------
CREATE TABLE usuario (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  rol ENUM('admin', 'vendedor') NOT NULL DEFAULT 'vendedor',
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- CLIENTE: personas que compran en la tienda
-- ------------------------------------------------------------
CREATE TABLE cliente (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  documento VARCHAR(30),
  telefono VARCHAR(30),
  email VARCHAR(100),
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- PRODUCTO: catálogo (guarda también el stock actual)
-- ------------------------------------------------------------
CREATE TABLE producto (
  id INT AUTO_INCREMENT PRIMARY KEY,
  categoria_id INT NOT NULL,
  nombre VARCHAR(120) NOT NULL,
  descripcion VARCHAR(255),
  precio DECIMAL(10,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  stock_minimo INT NOT NULL DEFAULT 5,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);

-- ------------------------------------------------------------
-- VENTA: cabecera de cada venta realizada
-- ------------------------------------------------------------
CREATE TABLE venta (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  usuario_id INT NOT NULL,
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  total DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (cliente_id) REFERENCES cliente(id),
  FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

-- ------------------------------------------------------------
-- DETALLE_VENTA: los productos que contiene cada venta
-- ------------------------------------------------------------
CREATE TABLE detalle_venta (
  id INT AUTO_INCREMENT PRIMARY KEY,
  venta_id INT NOT NULL,
  producto_id INT NOT NULL,
  cantidad INT NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (venta_id) REFERENCES venta(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES producto(id)
);

-- ------------------------------------------------------------
-- MOVIMIENTO_INVENTARIO: historial de entradas y salidas
-- de stock (una venta genera automáticamente una salida)
-- ------------------------------------------------------------
CREATE TABLE movimiento_inventario (
  id INT AUTO_INCREMENT PRIMARY KEY,
  producto_id INT NOT NULL,
  tipo ENUM('entrada', 'salida') NOT NULL,
  cantidad INT NOT NULL,
  motivo VARCHAR(150),
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (producto_id) REFERENCES producto(id)
);

-- ------------------------------------------------------------
-- Datos de ejemplo
-- ------------------------------------------------------------
INSERT INTO categoria (nombre) VALUES ('Ropa'), ('Alimentos'), ('Hogar');

-- Usuario admin de prueba -> contraseña: admin123
-- (el hash se genera con password_hash('admin123', PASSWORD_DEFAULT) en PHP)
INSERT INTO usuario (nombre, email, password_hash, rol) VALUES
('Administrador', 'admin@tienda.com', '$2b$10$SUf/WFRiY1PfpdFFHZwvWeLZfibGaJqbPVqvNK2Bd4iaZMIwW5yIW', 'admin');

INSERT INTO producto (categoria_id, nombre, descripcion, precio, stock, stock_minimo) VALUES
(1, 'Camiseta básica', 'Camiseta de algodón unisex', 35000, 40, 10),
(1, 'Pantalón jean', 'Jean clásico azul', 89000, 20, 5),
(2, 'Arroz 1kg', 'Arroz blanco marca propia', 4500, 100, 20),
(2, 'Aceite 1L', 'Aceite vegetal', 9800, 60, 15),
(3, 'Juego de sábanas', 'Sábanas dobles 100% algodón', 65000, 15, 5);
