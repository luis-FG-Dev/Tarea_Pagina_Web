<?php
// includes/auth.php
// Se incluye al inicio de cada página protegida.
// Si no hay sesión activa, redirige al login.

session_start();

function requerir_login(): void
{
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: index.php');
        exit;
    }
}

function usuario_actual(): array
{
    return [
        'id'     => $_SESSION['usuario_id'] ?? null,
        'nombre' => $_SESSION['usuario_nombre'] ?? '',
        'rol'    => $_SESSION['usuario_rol'] ?? '',
    ];
}
