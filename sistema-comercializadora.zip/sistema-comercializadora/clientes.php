<?php
require 'config.php';
require 'includes/auth.php';
requerir_login();

$titulo = 'Clientes';
$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar') {
    $id        = $_POST['id'] ?: null;
    $nombre    = trim($_POST['nombre']);
    $documento = trim($_POST['documento']);
    $telefono  = trim($_POST['telefono']);
    $email     = trim($_POST['email']);

    if ($id) {
        $stmt = $pdo->prepare('UPDATE cliente SET nombre=?, documento=?, telefono=?, email=? WHERE id=?');
        $stmt->execute([$nombre, $documento, $telefono, $email, $id]);
        $mensaje = 'Cliente actualizado.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO cliente (nombre, documento, telefono, email) VALUES (?,?,?,?)');
        $stmt->execute([$nombre, $documento, $telefono, $email]);
        $mensaje = 'Cliente creado.';
    }
}

if (isset($_GET['eliminar'])) {
    $stmt = $pdo->prepare('DELETE FROM cliente WHERE id = ?');
    $stmt->execute([(int) $_GET['eliminar']]);
    $mensaje = 'Cliente eliminado.';
}

$clienteEditar = null;
if (isset($_GET['editar'])) {
    $stmt = $pdo->prepare('SELECT * FROM cliente WHERE id = ?');
    $stmt->execute([(int) $_GET['editar']]);
    $clienteEditar = $stmt->fetch();
}

$clientes = $pdo->query('SELECT * FROM cliente ORDER BY nombre')->fetchAll();

require 'includes/header.php';
?>

<h3 class="mb-4">Clientes</h3>

<?php if ($mensaje): ?>
  <div class="alert alert-success"><?= htmlspecialchars($mensaje) ?></div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="card p-3">
      <h5><?= $clienteEditar ? 'Editar cliente' : 'Nuevo cliente' ?></h5>
      <form method="post">
        <input type="hidden" name="accion" value="guardar">
        <input type="hidden" name="id" value="<?= htmlspecialchars($clienteEditar['id'] ?? '') ?>">
        <div class="mb-2">
          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" class="form-control" required
                 value="<?= htmlspecialchars($clienteEditar['nombre'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label">Documento</label>
          <input type="text" name="documento" class="form-control"
                 value="<?= htmlspecialchars($clienteEditar['documento'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label">Teléfono</label>
          <input type="text" name="telefono" class="form-control"
                 value="<?= htmlspecialchars($clienteEditar['telefono'] ?? '') ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Correo</label>
          <input type="email" name="email" class="form-control"
                 value="<?= htmlspecialchars($clienteEditar['email'] ?? '') ?>">
        </div>
        <button class="btn btn-primary w-100" type="submit">Guardar</button>
        <?php if ($clienteEditar): ?>
          <a href="clientes.php" class="btn btn-link w-100">Cancelar edición</a>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card p-3">
      <table class="table align-middle">
        <thead><tr><th>Nombre</th><th>Documento</th><th>Teléfono</th><th>Correo</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($clientes as $c): ?>
          <tr>
            <td><?= htmlspecialchars($c['nombre']) ?></td>
            <td><?= htmlspecialchars($c['documento']) ?></td>
            <td><?= htmlspecialchars($c['telefono']) ?></td>
            <td><?= htmlspecialchars($c['email']) ?></td>
            <td class="text-end">
              <a href="clientes.php?editar=<?= $c['id'] ?>" class="btn btn-sm btn-outline-secondary">Editar</a>
              <a href="clientes.php?eliminar=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger"
                 onclick="return confirm('¿Eliminar este cliente?')">Eliminar</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
