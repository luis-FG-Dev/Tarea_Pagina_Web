<?php
// config.php
// Conexión única a la base de datos, reutilizada por todas las páginas.
// PDO se usa porque permite "prepared statements": el SQL y los datos
// viajan por separado, lo que evita inyección SQL.

$DB_HOST = 'localhost';
$DB_NAME = 'comercializadora';
$DB_USER = 'root';       // cambia esto por tu usuario de MySQL
$DB_PASS = '';           // cambia esto por tu contraseña de MySQL

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // lanza errores en vez de fallar en silencio
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // filas como arrays asociativos
        ]
    );
} catch (PDOException $e) {
    die('Error de conexión a la base de datos: ' . $e->getMessage());
}
